
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'CMSIS_DAP' 
 * Target:  'XMC4200' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_CMSIS_RTOS                  /* CMSIS-RTOS */
        #define RTE_CMSIS_RTOS_RTX              /* CMSIS-RTOS Keil RTX */
#define RTE_DEVICE
#define RTE_DEVICE_STARTUP
#define RTE_DEVICE_XMCLIB_GPIO
#define RTE_DEVICE_XMCLIB_SCU
#define RTE_DEVICE_XMCLIB_UART
#define RTE_Drivers_USBD
#define RTE_USB_Core                    /* USB Core */
#define RTE_USB_Device_0                /* USB Device 0 */
#define RTE_USB_Device_HID_0            /* USB Device HID instance 0 */

#endif /* RTE_COMPONENTS_H */
