var group___d_a_p___config___port_i_o__gr =
[
    [ "PIN_nRESET_IN", "group___d_a_p___config___port_i_o__gr.html#gad0de1a17d02af9a9959e4031d58b1eca", null ],
    [ "PIN_nRESET_OUT", "group___d_a_p___config___port_i_o__gr.html#ga6764592e610237a3e325ebaecba83760", null ],
    [ "PIN_nTRST_IN", "group___d_a_p___config___port_i_o__gr.html#gaa3849d1a7cc9945c05578bc4616f3e63", null ],
    [ "PIN_nTRST_OUT", "group___d_a_p___config___port_i_o__gr.html#ga4eebf6aa9628de5176632db0458cd234", null ],
    [ "PIN_SWCLK_TCK_CLR", "group___d_a_p___config___port_i_o__gr.html#gac95e157f51e8073cf740761bf59f09f3", null ],
    [ "PIN_SWCLK_TCK_IN", "group___d_a_p___config___port_i_o__gr.html#gaac4a182db3a1f3a3de04280dccb8d9d3", null ],
    [ "PIN_SWCLK_TCK_SET", "group___d_a_p___config___port_i_o__gr.html#ga197ad2824c91a8ea9ad0132951125217", null ],
    [ "PIN_SWDIO_IN", "group___d_a_p___config___port_i_o__gr.html#ga545a6a01ae522683c32e830683511c17", null ],
    [ "PIN_SWDIO_OUT", "group___d_a_p___config___port_i_o__gr.html#ga5e163176ee6bc9925f8f702d27d08f96", null ],
    [ "PIN_SWDIO_OUT_DISABLE", "group___d_a_p___config___port_i_o__gr.html#ga1fb4b84b48b39bcc28790cb45abb0c59", null ],
    [ "PIN_SWDIO_OUT_ENABLE", "group___d_a_p___config___port_i_o__gr.html#ga3fd30f1eb2feb4bb52d3c7e8c373d4d9", null ],
    [ "PIN_SWDIO_TMS_CLR", "group___d_a_p___config___port_i_o__gr.html#gab29c2d8f97388bb6ba336bab41b0ca53", null ],
    [ "PIN_SWDIO_TMS_IN", "group___d_a_p___config___port_i_o__gr.html#gaef0a34cb4eb3882c7ae05b9e1b0b7574", null ],
    [ "PIN_SWDIO_TMS_SET", "group___d_a_p___config___port_i_o__gr.html#gaad5e63cde6ce0b523d66ab4e05f974e7", null ],
    [ "PIN_TDI_IN", "group___d_a_p___config___port_i_o__gr.html#gaffb848049cb9da42e55731aa40c35429", null ],
    [ "PIN_TDI_OUT", "group___d_a_p___config___port_i_o__gr.html#ga57bf14c857b0c2d0227f2fd2a588c03b", null ],
    [ "PIN_TDO_IN", "group___d_a_p___config___port_i_o__gr.html#ga8f34a3b7d1c1ecdf7dbc0c527e16c0e5", null ],
    [ "PORT_JTAG_SETUP", "group___d_a_p___config___port_i_o__gr.html#ga33c16f83b54b07e2a62bb3423341537e", null ],
    [ "PORT_OFF", "group___d_a_p___config___port_i_o__gr.html#ga6522dd62895ffbb299294ec0b7c1b316", null ],
    [ "PORT_SWD_SETUP", "group___d_a_p___config___port_i_o__gr.html#gab8876acfd193c31fbe5246ca6ba9249e", null ]
];