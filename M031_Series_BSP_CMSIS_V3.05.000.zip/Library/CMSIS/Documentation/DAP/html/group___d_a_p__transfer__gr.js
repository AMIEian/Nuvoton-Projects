var group___d_a_p__transfer__gr =
[
    [ "DAP_TransferConfigure", "group___d_a_p___transfer_configure.html", null ],
    [ "DAP_Transfer", "group___d_a_p___transfer.html", null ],
    [ "DAP_TransferBlock", "group___d_a_p___transfer_block.html", null ],
    [ "DAP_TransferAbort", "group___d_a_p___transfer_abort.html", null ]
];